export class CreateTodoDto {
  readonly email: string;
  readonly pwd: string; 
}
