module.exports = {
  projects: [
    '<rootDir>/apps/frontend',
    '<rootDir>/apps/backend',
    '<rootDir>/libs/types',
  ],
};
