export class CreateProductDto {
    readonly name: string;
    readonly type: string; 
  }
  